THARU STORE — SHARED ORDERS FIX v3 (NEW SUPABASE PROJECT)

This ZIP is configured for your new Supabase project.
Project URL: https://aindlpgtfialcqijeusg.supabase.co

ONE-TIME SETUP:
1. Open this Supabase project Dashboard.
2. Open SQL Editor.
3. Paste/run ALL contents of SUPABASE_ORDERS_FIX.sql.
4. Deploy this ZIP to Netlify.
5. Test from a different phone: create/login to a customer account and submit a new order.
6. On the admin phone open Admin Orders -> Refresh Orders.

EXPECTED RESULT:
Customer phone order -> Supabase cloud -> Admin phone Admin Orders.

The customer order is also kept in localStorage as a fallback, but localStorage is device/browser-specific and cannot synchronize between phones by itself.

ADMIN:
Only chaudharyudip48@gmail.com is allowed to see Admin Orders and Rate Customize.

IMPORTANT SECURITY NOTE:
The supplied SQL currently grants broad browser access to the orders table so the existing client-side admin system can read/update it. For a production store, Supabase Auth/RLS should be used to enforce admin-only reads/updates server-side.

SEO SITE NAME:
The homepage now declares the preferred site name as "Kolhabi Store NP" using the page title, Open Graph site name, application name, manifest name, and WebSite structured data. Google Search generates site names automatically, so an already-indexed result may continue showing "Kolhabi Store" until Google recrawls/reprocesses the site.


MOBILE ORDER NOTIFICATION
- Admin account: chaudharyudip48@gmail.com
- When a new cloud/Supabase order arrives, the admin browser checks every 8 seconds.
- If browser notifications are allowed, a mobile/browser notification appears with customer, product and amount.
- On first check, existing orders are marked as already seen so old orders do not trigger notifications.
- This works while the site/PWA is running in the browser/background. Full notification delivery after Chrome/site is completely killed requires a Web Push sender/server (not included in this static ZIP).
- On Android, open the deployed HTTPS site/PWA as Admin and allow Notifications when Chrome asks.

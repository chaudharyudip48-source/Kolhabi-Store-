CUSTOMER SUPPORT TICKETS FIX

Customer Support inquiries now save locally and also sync to the shared Supabase database.

When a customer submits an inquiry:
- It appears in that customer's My Tickets.
- If the support_tickets table is configured, it is uploaded to Supabase.

When the authorized admin account (chaudharyudip48@gmail.com) opens Customer Support -> My Tickets:
- All customer support inquiries are loaded from Supabase.
- Customer name and email are shown to the admin.
- Other customer accounts only see their own tickets.

IMPORTANT: Run the updated SUPABASE_ORDERS_FIX.sql in Supabase SQL Editor once. It includes the support_tickets table and policies.
